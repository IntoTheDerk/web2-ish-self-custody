# Changelog

All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses
[Semantic Versioning](https://semver.org/).

## [0.0.1-alpha.0] — Unreleased (alpha pre-release)

Renumbers kalvora.js as an **alpha**, makes Ed25519 HD derivation standard
SLIP-0010, and switches the SDK to the official Kalvora protos (`txn.proto`,
`validator.proto`, `kal_api.proto`).

The version goes *down* from 0.1.0 on purpose: neither kalvora.js nor the
Kalvora network is live, and 0.1.0 was published before the key derivation
and wire protocol were settled. 0.1.0 should be deprecated on npm in favour
of this release; the `0.0.x` line carries no compatibility promise between
releases.

### Changed

- **Breaking (keys): Ed25519 HD derivation is now standard
  [SLIP-0010](https://github.com/satoshilabs/slips/blob/master/slip-0010.md).**
  It previously used a scheme inherited from zera.js — master key
  `"Kalvora seed"` and a child step over little-endian `index || key` — that
  was described as SLIP-0010 but was not. It now uses the `"ed25519 seed"`
  master key and `0x00 || key || ser32BE(index)`, so every SLIP-0010 wallet
  derives the same Ed25519 key from the same seed and path. **The same
  mnemonic now gives a different Ed25519 address**: the BIP-39 test
  mnemonic's first address changes from
  `Hb6KH2BhgcjCYnc3JwDU1VNfbLds2yfMDMVwZGUWSunE` to
  `35q7SEc9HVV7Gd9oVKCnZjPMxpLrH9DftTcBUyHahTZP`. No Kalvora wallet had
  shipped on the old scheme, so there is no legacy option.
- **Breaking:** an Ed25519 derivation path with an unhardened segment now
  throws, since SLIP-0010 defines only hardened Ed25519 children. Every path
  the SDK builds itself is already fully hardened.
- **Ed448 derivation is unchanged.** SLIP-0010 does not define Ed448 and no
  other standard does, so Ed448 keeps Kalvora's scheme byte for byte, now
  pinned by reference vectors. See
  [docs/guides/hd-derivation.md](./docs/guides/hd-derivation.md).

- **Breaking:** protobuf packages renamed `zera_txn` → `kal_txn`,
  `zera_validator` → `kal_validator`, `zera_api` → `kal_api`. Every generated
  `$typeName` / `typeName` changes accordingly (e.g. `kal_txn.CoinTXN`), as do
  `SerializedTransaction.type`, `SMART_SWAP_TRANSACTION_TYPE`
  (`kal_txn.SmartContractExecuteTXN`) and `KalvoraRpcError.service`.
  `zera_guardian` is unchanged (the guardian proto was not re-issued).
- **Breaking (wire):** fully qualified gRPC paths are now
  `/kal_api.APIService/*`, `/kal_txn.TXNService/*`,
  `/kal_validator.ValidatorService/*`. The default transport still sends the
  Envoy aliases `/api/*`, `/txn/*`, `/validator/*`, `/guardian/*`
  (unchanged); only callers passing their own `transport` send the fully
  qualified path. Nodes and their Envoy routes must serve the `kal_*`
  services.
- **Breaking:** the API proto file is now `proto/kal_api.proto` and its
  bindings `proto/generated/kal_api_pb.js` (was `api.proto` / `api_pb.js`);
  `dist/proto/` ships `kal_api.proto` and now also `guardian.proto`.
- Proto sources are committed byte-identical to the official release (CRLF
  line endings, no repo-local options; `proto/.gitattributes` disables
  line-ending conversion). `proto:sync` / `proto:check` accept the official
  flat release or a kalvora-indexer checkout, no longer normalise trailing
  newlines, and treat `guardian.proto` as optional.
- `deserializeTransaction` and `getSchemaForTypeName` accept legacy
  `zera_txn.*` type names (message bytes are unchanged by the rename); the
  Smart Swap facade accepts a legacy `zera_txn.SmartContractExecuteTXN`
  envelope and reports it as `kal_txn`.
- **Breaking:** native token symbol is `KALV` everywhere. `KALVORA_SYMBOL`
  (and therefore `wallet.symbol` on created wallets) changes from `KAL` to
  `KALV`, matching `KALVORA_NETWORKS.protonet.nativeSymbol`;
  `TransactionFormatter.formatAmount` defaults to `KALV`, and the internal
  `formatAmount` helper labels the native token `KALV` instead of slicing the
  contract ID. The `KAL`+Base58 contract-ID prefix is unchanged.
- **Breaking (default endpoint):** the default gRPC-Web origin is now
  `https://kal-proto.visiondynamics.ch` (Envoy, port 443), replacing
  `kal-protonet.visiondynamics.ch`, in `createClient`, `PROTONET_GRPC_CONFIG`,
  `KALVORA_PROTONET_ENDPOINT`, the `protonet` network preset, examples and
  docs. Callers passing an explicit `host`/`endpoint` are unaffected.

### Added

- `kalvora.js/wallet`: the wallet surface on its own (mnemonics, HD
  derivation, key pairs, address encoding), depending only on
  `@noble/curves`, `@noble/hashes`, `bip39`, and `bs58`, with no network or
  protobuf code. ESM-only; the same exports remain on the main entry.
- `deriveHDPrivateKey(seed, path?, keyType?)`: the 32-byte key at a path and
  nothing else, zeroing every intermediate node. Defaults to Ed25519 at
  `m/44'/5258'/0'/0'/0'`.
- `docs/guides/hd-derivation.md`: the byte-level derivation spec for both key
  types, with reference vectors; the SLIP-0010 Ed25519 test vector 1 and the
  Kalvora vectors are checked in `hd-derivation-vectors.test.ts`.

- `TextGovernanceProposalInput.proposalType` (`ProposalType`, field 11).
  Defaults to `ProposalType.NONE`, which is not encoded, so existing proposals
  are byte-identical; the v1 golden vector is unchanged.
- `ProposalLedgerView.statuses` (`ProposalStatusView[]`) from
  `ProposalLedgerResponse.proposal_statuses`, with the pre-governance phase,
  outcome, window dates, fees, `promotionPending` and the contract's
  `PreGovernance` policy.
- `TransactionResult.proposalIdentifier` (`TXNStatusFees.proposal_identifier`).
- `CheckpointInfo.fileHash`, `publicKey` and `signature` (returned as
  received; not verified by the SDK).
- Exports: `ProposalType`, `PROPOSAL_PHASE`, `PRE_GOVERNANCE_OUTCOME`,
  `ProposalStatusView`, `normalizeTransactionTypeName`.
- New protocol fields are available through the raw bindings (`proto.*`):
  `NFT.parameters/expiry/valid_from`, `Voter.phase`, `Proposal` fields 19–25,
  `ProposalResult.pre_governance`.

### Removed

- **Breaking:** `ValidatorInfoInput.stakedContractIds`. `Validator` field 5
  (`staked_contract_ids`) is reserved because staking is KALV-only; passing the
  option now throws instead of being silently dropped.
- **Breaking:** `StakeMultipliers` message (`proto.validator`).
- **Breaking:** `ZeraGovernanceAuth` renamed to `KalGovernanceAuth`;
  `ProcessLedger.cycle_contract_ids` changed from `bytes` to `string`
  (canonical Base58 contract IDs). Neither was used by the typed API.

## [0.1.0] — 2026-09-25

Superseded by 0.0.1-alpha.0; do not use. Its Ed25519 HD derivation was not
SLIP-0010 (see above).

First public beta of the Kalvora SDK. As a 0.x release, APIs may change in
any minor version before 1.0.0.

kalvora.js is derived from the Apache-2.0 zera.js SDK. It is Kalvora-native,
covers the full protocol surface of the current node protobuf definitions,
and hardens signing and submission. The "Changed" and "Removed" sections list
differences from zera.js and its early Kalvora port; see
[docs/guides/coming-from-zera-js.md](./docs/guides/coming-from-zera-js.md).

### Added

- `KalvoraClient` facade with `submit`, `submitAndWait`, cached tip height, and
  `KALVORA_NETWORKS` presets / `resolveNetwork`.
- `KalvoraQueryClient` covering every client-facing `APIService` RPC with
  `bigint` amounts, base58 addresses, and hex hashes; plus
  `getLatestBlockHeight`, `waitForTransaction`, `getBalanceOrZero`,
  `getCurrencyEquivalent`, `getContractSupply`.
- `ValidatorQueryClient` (read-only `ValidatorService`, incl. signed
  `GetCheckpointInfo` / `SyncValidatorList`) and `GuardianQueryClient`.
- Block and result decoders: `summarizeBlock`, `listBlockTransactions`,
  `findTransactionResult`, `partsToWhole`, `formatScaled`.
- Transaction builders (build / create / send) for `MintTXN`, `RevokeTXN`,
  `QuashTXN`, `ComplianceTXN`, `ExpenseRatioTXN`, `AllowanceTXN` (+ revoke
  helper, USD ↔ currency-equivalent conversion), `DelegatedTXN`,
  `ValidatorRegistration` (+ `attachGeneratedSignature`), and
  `ValidatorHeartbeat`; `createTextGovernanceProposalTXN` /
  `sendGovernanceProposalTXN`.
- Shared `buildStandardTransaction` pipeline and `StandardTXNOptions`
  (`safeSend`, interface fees, offline/deterministic construction) with strict
  input parsers.
- `KalvoraRpcError` with the real gRPC status code, `RpcCode`,
  `isKalvoraRpcError`.
- `proto` namespace exposing the generated bindings; `dex` namespace export.
- `npm run proto:sync` / `proto:check` (kalvora-indexer is the source of
  truth), `npm run docs` (TypeDoc), `npm run validate`, `npm run test:live`.
- Guides: getting started, transactions, querying, architecture, migration.

### Changed (from zera.js / the early port)

- **Breaking:** native token is `KALXvxhUMJERCse4e6b2jeXFkcqqpiUByQQckvPZm4szmF3Ao`;
  the network rejects the former `KAL111112` placeholder.
- **Breaking:** `Zera*` identifiers renamed to `Kalvora*`; builder names made
  consistent (`createContractTXN`, `createContractUpdateTXN`, …); see the
  migration guide for the full table. Wire-level names are unchanged.
- **Breaking:** zera.js-style query helpers (`getNonce`, `getBalance`, `getBaseFee`,
  `getExchangeRate`, token-info helpers, `createValidatorAPIClient`) are no
  longer exported; use `createQueryClient()`.
- **Breaking:** staking / bootstrapping / bridge options take
  `feeAmountParts` (smallest units) instead of the misleading `feeAmountUsd`,
  whose value was passed through as raw parts.
- `submitTransaction` and `send*` reject unsigned transactions before any
  network call and always return the real hex hash.
- The build no longer installs packages globally or rewrites sources with
  `eslint --fix`.
- `npm test` is plain vitest with a quiet reporter.

### Fixed

- RPC errors lost their status code (surfaced as `[unknown]`) because
  ConnectRPC re-wraps interceptor exceptions; errors are now normalised at the
  client boundary for every transport.
- `signWithKey` / `signAndFinalize` silently returned an unsigned transaction
  when `base` was missing, and signed over stale signature/hash material when
  re-signing.
- `signCoinTXN` / `signCoinTXNWithKeys` wrote signatures into a detached
  object when `auth` was unset, returning an unsigned (but hashed) CoinTXN.
- `feeAmountParts` is written to `BaseTXN.fee_amount` in canonical form
  (e.g. `' 5 '`/`'007'` previously went on the wire verbatim).
- `ValidatorRegistration` automatic fees now include the generated-key
  signature size.

### Removed (from zera.js / the early port)

- Deprecated aliases (`ZERA_*`, `ZV_*`, `MAINNET_GRPC_CONFIG`,
  `TESTNET_GRPC_CONFIG`, `*ItemMint*`, `*NFTTransfer*`,
  `*SmartContractDeploy*`, Solana `*2022*` aliases).
- Unused dependencies `dotenv`, `bip32` (runtime) and `mocha`, `chai`,
  `chokidar`, `glob`, `minimist` (dev); custom test runners; the legacy
  connectivity test that submitted an empty `CoinTXN`.

